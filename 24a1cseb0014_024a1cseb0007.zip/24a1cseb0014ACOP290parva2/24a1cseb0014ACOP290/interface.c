#include "spreadsheet.h"
#include <stdio.h>

/* Recursively prints A, B... Z, AA, AB... */
void print_col_label(int n) {
    if (n < 0) return;
    print_col_label((n / 26) - 1);
    printf("%c", (n % 26) + 'A');
}

/* Display 10x10 window */
void display_window(Spreadsheet* sheet) {

    // Clear screen (works on most terminals)
    printf("\033[H\033[J");

    printf("\n    ");

    //////////////////////////////////////////////////////////
    // COLUMN HEADERS
    //////////////////////////////////////////////////////////

    for (int j = 0; j < 10 && (sheet->start_col + j) < sheet->cols; j++) {
        int col_idx = sheet->start_col + j;

        printf("%4s", "");   // spacing
        print_col_label(col_idx);
    }
    printf("\n");

    //////////////////////////////////////////////////////////
    // GRID
    //////////////////////////////////////////////////////////

    for (int i = 0; i < 10 && (sheet->start_row + i) < sheet->rows; i++) {

        printf("%3d ", sheet->start_row + i + 1);

        for (int j = 0; j < 10 && (sheet->start_col + j) < sheet->cols; j++) {

            Cell c = sheet->grid[sheet->start_row + i][sheet->start_col + j];

            if (c.is_err)
                printf("[ ERR ]");
            else
                printf("%5d", c.value);
        }

        printf("\n");
    }

    printf("\n");
    fflush(stdout);
}