#include <stdio.h>
#include <string.h>

#include "spreadsheet.h"

//////////////////////////////////////////////////////////////
// DEPENDENCY STORAGE
//////////////////////////////////////////////////////////////

/*
    dependents[r][c][k] = list of cells depending on (r,c)
*/

#define MAX 1000

int dep_count[MAX][MAX];
int dep_r[MAX][MAX][100];
int dep_c[MAX][MAX][100];

/*
    store formulas
*/
Formula stored_formula[MAX][MAX];
int has_formula[MAX][MAX];

//////////////////////////////////////////////////////////////
// CLEAR OLD DEPENDENCIES
//////////////////////////////////////////////////////////////

void clear_dependencies(int r, int c) {

    for (int i = 0; i < MAX; i++) {
        for (int j = 0; j < MAX; j++) {

            int k = 0;
            while (k < dep_count[i][j]) {

                if (dep_r[i][j][k] == r && dep_c[i][j][k] == c) {

                    // shift left
                    for (int x = k; x < dep_count[i][j] - 1; x++) {
                        dep_r[i][j][x] = dep_r[i][j][x + 1];
                        dep_c[i][j][x] = dep_c[i][j][x + 1];
                    }

                    dep_count[i][j]--;
                } else {
                    k++;
                }
            }
        }
    }
}

//////////////////////////////////////////////////////////////
// ADD DEPENDENCY
//////////////////////////////////////////////////////////////

void add_dependency(int sr, int sc, int dr, int dc) {

    int k = dep_count[sr][sc];

    dep_r[sr][sc][k] = dr;
    dep_c[sr][sc][k] = dc;

    dep_count[sr][sc]++;
}

//////////////////////////////////////////////////////////////
// EXTRACT DEPENDENCIES
//////////////////////////////////////////////////////////////

void extract_dependencies(Expression expr, int tr, int tc) {

    if (expr.type == EXPR_VALUE) {

        if (expr.val.type == VAL_CELL) {
            add_dependency(expr.val.row, expr.val.col, tr, tc);
        }
    }

    else if (expr.type == EXPR_ARITH) {

        if (expr.arith.left.type == VAL_CELL) {
            add_dependency(expr.arith.left.row, expr.arith.left.col, tr, tc);
        }

        if (expr.arith.right.type == VAL_CELL) {
            add_dependency(expr.arith.right.row, expr.arith.right.col, tr, tc);
        }
    }

    else if (expr.type == EXPR_FUNC) {

        if (!expr.func.is_range) {

            if (expr.func.single_val.type == VAL_CELL) {
                add_dependency(expr.func.single_val.row,
                               expr.func.single_val.col,
                               tr, tc);
            }
        }

        else {
            int r1, c1, r2, c2;

            if (parse_range(expr.func.range, &r1, &c1, &r2, &c2)) {

                for (int i = r1; i <= r2; i++) {
                    for (int j = c1; j <= c2; j++) {
                        // Skip if the cell is the target cell itself
                        if (i == tr && j == tc)
                            continue;
                        add_dependency(i, j, tr, tc);
                    }
                }
            }
        }
    }
}

//////////////////////////////////////////////////////////////
// CYCLE DETECTION (DFS)
//////////////////////////////////////////////////////////////

int visited[MAX][MAX];
int stack[MAX][MAX];

int dfs_cycle(int r, int c) {

    if (stack[r][c]) return 1;
    if (visited[r][c]) return 0;

    visited[r][c] = 1;
    stack[r][c] = 1;

    for (int k = 0; k < dep_count[r][c]; k++) {

        int nr = dep_r[r][c][k];
        int nc = dep_c[r][c][k];

        if (dfs_cycle(nr, nc))
            return 1;
    }

    stack[r][c] = 0;
    return 0;
}

int detect_cycle(Spreadsheet *sheet) {

    memset(visited, 0, sizeof(visited));
    memset(stack, 0, sizeof(stack));

    for (int i = 0; i < sheet->rows; i++) {
        for (int j = 0; j < sheet->cols; j++) {

            if (dfs_cycle(i, j))
                return 1;
        }
    }

    return 0;
}

//////////////////////////////////////////////////////////////
// PROPAGATE UPDATE
//////////////////////////////////////////////////////////////

void propagate(Spreadsheet *sheet, int r, int c) {

    for (int k = 0; k < dep_count[r][c]; k++) {

        int nr = dep_r[r][c][k];
        int nc = dep_c[r][c][k];

        if (has_formula[nr][nc]) {

            evaluate_formula(sheet, stored_formula[nr][nc]);
            propagate(sheet, nr, nc);
        }
    }
}

//////////////////////////////////////////////////////////////
// MAIN UPDATE FUNCTION
//////////////////////////////////////////////////////////////

void update_with_dependencies(Spreadsheet *sheet, Formula f) {

    int r = f.target_row;
    int c = f.target_col;

    //////////////////////////////////////////////////////////
    // REMOVE OLD LINKS
    //////////////////////////////////////////////////////////

    clear_dependencies(r, c);

    //////////////////////////////////////////////////////////
    // STORE FORMULA
    //////////////////////////////////////////////////////////

    stored_formula[r][c] = f;
    has_formula[r][c] = 1;

    //////////////////////////////////////////////////////////
    // ADD NEW LINKS
    //////////////////////////////////////////////////////////

    extract_dependencies(f.expr, r, c);

    //////////////////////////////////////////////////////////
    // CHECK CYCLE
    //////////////////////////////////////////////////////////

    if (detect_cycle(sheet)) {
        printf("Error: Circular dependency\n");
        has_formula[r][c] = 0;
        return;
    }

    //////////////////////////////////////////////////////////
    // EVALUATE CURRENT
    //////////////////////////////////////////////////////////

    evaluate_formula(sheet, f);

    //////////////////////////////////////////////////////////
    // PROPAGATE
    //////////////////////////////////////////////////////////

    propagate(sheet, r, c);
}