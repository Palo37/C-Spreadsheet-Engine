#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void run_test(const char *input, const char *output) {
    char command[512];
    char temp_output[512];
    
    // Create unique temp file for each test
    sprintf(temp_output, "temp_test.txt");
    
    // Run the sheet program with input
    sprintf(command, "sheet.exe 2 2 < %s > %s", input, temp_output);
    system(command);
    
    // Compare with expected output using fc
    sprintf(command, "fc /n %s %s", temp_output, output);
    int result = system(command);
    
    // Check if files match (fc returns 0 for match, 1 for different)
    if (result == 0) {
        printf("PASS: %s\n", input);
    } else {
        printf("FAIL: %s\n", input);
    }
    
    // Clean up temp file
    remove(temp_output);
}

int main() {
    printf("Running test suite...\n");
    printf("======================\n\n");
    
    run_test("tests/test1.txt", "tests/out1.txt");
    run_test("tests/test2.txt", "tests/out2.txt");
    
    printf("\n======================\n");
    printf("Done.\n");
    return 0;
}
