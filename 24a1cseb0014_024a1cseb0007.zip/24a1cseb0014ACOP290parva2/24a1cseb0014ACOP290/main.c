#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "spreadsheet.h"

//////////////////////////////////////////////////////////////
// INITIALIZATION
//////////////////////////////////////////////////////////////

Spreadsheet* create_sheet(int rows, int cols) {
    Spreadsheet *sheet = (Spreadsheet*)malloc(sizeof(Spreadsheet));

    sheet->rows = rows;
    sheet->cols = cols;
    sheet->start_row = 0;
    sheet->start_col = 0;

    sheet->grid = (Cell**)malloc(rows * sizeof(Cell*));

    for (int i = 0; i < rows; i++) {
        sheet->grid[i] = (Cell*)malloc(cols * sizeof(Cell));

        for (int j = 0; j < cols; j++) {
            sheet->grid[i][j].value = 0;
            sheet->grid[i][j].is_err = 0;
        }
    }

    return sheet;
}

//////////////////////////////////////////////////////////////
// CLEANUP
//////////////////////////////////////////////////////////////

void free_sheet(Spreadsheet *sheet) {
    for (int i = 0; i < sheet->rows; i++) {
        free(sheet->grid[i]);
    }
    free(sheet->grid);
    free(sheet);
}

//////////////////////////////////////////////////////////////
// SCROLL HANDLING
//////////////////////////////////////////////////////////////

void handle_scroll(Spreadsheet *sheet, char cmd) {
    int step = 10;

    if (cmd == 'w' && sheet->start_row - step >= 0)
        sheet->start_row -= step;

    else if (cmd == 's' && sheet->start_row + step < sheet->rows)
        sheet->start_row += step;

    else if (cmd == 'a' && sheet->start_col - step >= 0)
        sheet->start_col -= step;

    else if (cmd == 'd' && sheet->start_col + step < sheet->cols)
        sheet->start_col += step;
}

//////////////////////////////////////////////////////////////
// SCROLL TO CELL
//////////////////////////////////////////////////////////////

void scroll_to_cell(Spreadsheet *sheet, const char *cell) {
    int r, c;
    parse_cell(cell, &r, &c);

    sheet->start_row = r;
    sheet->start_col = c;
}

//////////////////////////////////////////////////////////////
// MAIN LOOP
//////////////////////////////////////////////////////////////

int main(int argc, char *argv[]) {

    if (argc != 3) {
        printf("Invalid arguments\n");
        return 1;
    }

    int rows = atoi(argv[1]);
    int cols = atoi(argv[2]);

    if (rows < 1 || rows > 999 || cols < 1 || cols > 18278) {
        printf("Invalid sheet size\n");
        return 1;
    }

    Spreadsheet *sheet = create_sheet(rows, cols);

    char input[256];
    int output_enabled = 1;

    CommandType cmd;
    Formula f;

    double last_time = 0.0;
    char status[64] = "ok";

    while (1) {

        if (output_enabled)
            display_window(sheet);

        printf("[%.1f] (%s) > ", last_time, status);

        if (!fgets(input, sizeof(input), stdin))
            break;

        input[strcspn(input, "\n")] = '\0';

        clock_t start = clock();

        cmd = parse_command(input, &f);
        strcpy(status, "ok");

        //////////////////////////////////////////////////////////
        // HANDLE COMMANDS
        //////////////////////////////////////////////////////////

        if (cmd == CMD_QUIT) {
            break;
        }

        else if (cmd == CMD_SCROLL) {
            handle_scroll(sheet, input[0]);
        }

        else if (cmd == CMD_HELPER) {

            if (strcmp(input, "disable_output") == 0) {
                output_enabled = 0;
            }

            else if (strcmp(input, "enable_output") == 0) {
                output_enabled = 1;
            }

            else if (strncmp(input, "scroll_to", 9) == 0) {
                char cell[32];

                if (sscanf(input, "scroll_to %s", cell) == 1) {
                    scroll_to_cell(sheet, cell);
                    // Always display window for scroll_to, regardless of output_enabled
                    display_window(sheet);
                } else {
                    strcpy(status, "Invalid scroll_to");
                }
            }
        }

        else if (cmd == CMD_FORMULA) {
            update_with_dependencies(sheet, f);
        }

        else {
            strcpy(status, "unrecognized cmd");
        }

        //////////////////////////////////////////////////////////
        // TIME CALCULATION
        //////////////////////////////////////////////////////////

        clock_t end = clock();
        last_time = (double)(end - start) / CLOCKS_PER_SEC;
    }

    free_sheet(sheet);
    return 0;
}